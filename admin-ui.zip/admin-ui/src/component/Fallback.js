import React from "react";

const Fallback = () => {
  return <h1 style={{ color: "#FF0000" }}>Something Went Wrong </h1>;
};

export default Fallback;
